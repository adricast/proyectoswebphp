

<?php $__env->startSection('titulo', 'ReikoSoft'); ?>
<?php $__env->startSection('reikosoft-active', 'active'); ?>

<?php $__env->startSection('contenidoreiko'); ?>
    <section class="containerreiko">
        
        <img src="<?php echo e(route('recursos.show', ['img', 'fondoreiko.png'])); ?>" alt="">
    </section>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('reikosoft.contenedor.contenedor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/reikosoft/presentacion.blade.php ENDPATH**/ ?>