

<?php $__env->startSection('titulo', 'ReikoSoft'); ?>
<?php $__env->startSection('reikosoft-active', 'active'); ?>

<?php $__env->startSection('contenidoreiko'); ?>

    <script src="<?php echo e(route('recursos.show', ['js/reiko', 'marcasreiko.js'])); ?>"></script>
    Busqueda
    <input type="text" name="busqueda" id="busqueda" placeholder="Busqueda de Datos" onkeyup="consultaDatos()" style="width: 200px;">
   
    <section class="containerreiko">
       
        <div class="contenedormodulos" id="contenedorelemento">
            <a href="<?php echo e(route('marcas.create')); ?>">
                <div class="target">
                        
                        <img src="<?php echo e(route('recursos.show',['img/marcas', 'mas.png'])); ?>" alt="Ventas">
                        <p>Nueva Marca </p>
                </div>
            </a>
            
            <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a>
                    <div class="target">
                    <?php if($marca->foto): ?>
                        <img src="<?php echo e(asset('img/marcas/' . $marca->foto)); ?>" alt="<?php echo e($marca->foto); ?>">
                    <?php else: ?>
                            <img src="<?php echo e(route('recursos.show', ['img', 'logotype.png'])); ?>" alt=""  height="150px" width="150px">
                    <?php endif; ?>
                      <p><?php echo e($marca->nombre); ?></p>
                        <div class="botones">
                            
                            <button onclick="eliminarDatos('<?php echo e($marca->id); ?>')">
                                <i class="fas fa-trash"></i> 
                            </button>

                            
                            <button class="btneditar" onclick="modificarDatos('<?php echo e($marca->id); ?>')">
                                <span class="fa fa-edit"></span>
                            </button>
                            
                        </div>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           
        </div>
     
    </section>
    
    <?php echo $__env->make('reikosoft.marcas.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php $__env->stopSection(); ?>
   
<?php echo $__env->make('reikosoft.contenedor.contenedor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/reikosoft/marcas/index.blade.php ENDPATH**/ ?>