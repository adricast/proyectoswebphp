

<?php $__env->startSection('titulo', 'Tecnologías'); ?>
<?php $__env->startSection('tecnologias-active', 'active'); ?>

<?php $__env->startSection('contenido'); ?>
    <?php echo $__env->make('contenidos.introtecnologias', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('contenidos.pie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('estructura.cabecera', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/paginas/tecnologias.blade.php ENDPATH**/ ?>