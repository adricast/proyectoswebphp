

<?php $__env->startSection('titulo', 'ReikoSoft'); ?>
<?php $__env->startSection('reikosoft-active', 'active'); ?>

<?php $__env->startSection('contenidoreiko'); ?>

    <script src="<?php echo e(route('recursos.show', ['js/reiko', 'caracteristicasreiko.js'])); ?>"></script>
    <script src="<?php echo e(route('recursos.show', ['js/reiko', 'subcaracteristicasreiko.js'])); ?>"></script>
 
    <div class="contenedorbusqueda">
        Busqueda
        <input type="text" name="busqueda" id="busqueda" placeholder="Ingrese el Codigo del Producto"  style="width: 200px;">
        <input type="button" value="buscar"  onclick="consultaProductoCodigo()">
    </div>
   
    <section class="containerreiko2">
        <div class="containerelemento">
            <div class="elemento1">
                <label for="codigo">Codigo</label>
                <input type="text" name="codigo" id="codigo" readonly>
            </div>
            <div class="elemento2">
                <label for="nombre">Producto</label>
                <input type="text" name="nombre" id="nombre" readonly>
            </div>
            <div class="elemento3">
                <label for="descripcion">Descripcion</label>
                <input type="text" name="descripcion" id="descripcion" readonly>
            </div>
            <div class="elemento4">
                <label for="marca">Marca</label>
                <input type="text" name="marca" id="marca" readonly>
            </div>
        </div>
        <div class="contenedorcaracteristicas" id="contenedorcaracteristicas">
            <!-- Aquí se generará dinámicamente el contenido de las características -->
        </div>
              
        
       
        
       
    </section>
    
   

<?php $__env->stopSection(); ?>
   
<?php echo $__env->make('reikosoft.contenedor.contenedor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/reikosoft/caracteristicas/index.blade.php ENDPATH**/ ?>