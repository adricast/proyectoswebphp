<main class="contact-form">
    <div class="form-container">
        
        <div class="form-title">
            <h1>Contactanos</h1>
        </div>
        <div class="form-section">
            <h2><i class="fa fa-envelope" aria-hidden="true"></i></h2>
            <form action="<?php echo e(route('contactanos.store')); ?>" id="miFormulario" method="post" enctype="multipart/form-data" novalidate>
                <?php echo csrf_field(); ?>
                <input type="text" id="nombre" name="nombre" placeholder="Nombre" value="<?php echo e(isset($datos['nombre']) ? $datos['nombre'] : ''); ?>" required>
                <input type="tel" id="telefono" name="telefono" placeholder="Teléfono" value="<?php echo e(isset($datos['telefono']) ? $datos['telefono'] : ''); ?>" required>
                <input type="text" id="asunto" name="asunto" placeholder="Asunto" value="<?php echo e(isset($datos['asunto']) ? $datos['asunto'] : ''); ?>" required>
                <input type="email" id="correo" name="correo" placeholder="Correo electrónico" value="<?php echo e(isset($datos['correo']) ? $datos['correo'] : ''); ?>" required>
                <textarea id="mensaje" placeholder="Mensaje" name="mensaje" rows="4" required><?php echo e(isset($datos['mensaje']) ? $datos['mensaje'] : ''); ?></textarea>
                <button type="submit">Enviar</button>
            </form>
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</main>
<?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/contenidos/contacto.blade.php ENDPATH**/ ?>