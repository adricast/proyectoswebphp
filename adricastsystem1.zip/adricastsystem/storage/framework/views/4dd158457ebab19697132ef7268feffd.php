<footer class="footer">
  <div class="container">
    <div class="footer-content">
      <div class="footer-logo">
        <img src="<?php echo e(route('recursos.show', ['img', 'min.png'])); ?>" alt="Logo">
      
      </div>
      <div class="footer-links">
        <ul>
          <li><a href="<?php echo e(route('paginas.empleo')); ?>">Trabaja con nosotros</a></li>
          <li><a href="#">Servicios</a></li>
          <li><a href="<?php echo e(route('paginas.contactanos')); ?>">Contactanos</a></li>
          <li><a href="#">Cursos</a></li>
          <li><a href="<?php echo e(route('paginas.tecnologias')); ?>">Tecnologías</a></li>
          <li><a href="#">Comunidades</a></li>
        </ul>
      </div>
      <div class="footer-social">
        <ul>
          <li><a href="#"><i class="fab fa-facebook"></i></a></li>
          <li><a href="#"><i class="fab fa-twitter"></i></a></li>
          <li><a href="#"><i class="fab fa-instagram"></i></a></li>
          <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <p>Derechos reservados 2023 © ADRICAST SYSTEM</p>
    </div>
  </div>
</footer>
<?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/contenidos/pie.blade.php ENDPATH**/ ?>