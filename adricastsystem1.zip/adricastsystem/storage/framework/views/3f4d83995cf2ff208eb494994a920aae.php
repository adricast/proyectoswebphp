

<?php $__env->startSection('titulo', 'ReikoSoft'); ?>
<?php $__env->startSection('reikosoft-active', 'active'); ?>

<?php $__env->startSection('contenidoreiko'); ?>

    <script src="<?php echo e(route('recursos.show', ['js/reiko', 'modulosreiko.js'])); ?>"></script>
 
    <section class="containerreiko">
       
        <div class="contenedormodulos">
            <a href="<?php echo e(route('cmodulos.create')); ?>">
                <div class="target">
                        
                        <img src="<?php echo e(route('recursos.show',['img/modulos', 'mas.png'])); ?>" alt="Ventas">
                        <p>Nuevo Modulo </p>
                </div>
            </a>
            <a href="<?php echo e(route('posts.index')); ?>">
                <div class="target">
                    
                    <img src="<?php echo e(route('recursos.show',['img/modulos', 'home.png'])); ?>" alt="Ventas">
                    <p>HOME</p>
                </div>
            </a>
            <a href="<?php echo e(route('cmodulos.index')); ?>">
                <div class="target">
                    
                    <img src="<?php echo e(route('recursos.show',['img/modulos', 'modulos.png'])); ?>" alt="Ventas">
                    <p>MODULOS</p>
                   
                </div>
            </a>
            <?php $__currentLoopData = $modulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Route::has($modulo->ruta.'.index')): ?>
                <a  ondblclick="redirigir('<?php echo e($modulo->ruta); ?>') ">
                    <div class="target">
                    <img src="<?php echo e(asset('img/modulos/' . $modulo->icono)); ?>" alt="<?php echo e($modulo->icono); ?>">
                    <p><?php echo e($modulo->nombre); ?></p>
                        <div class="botones">
                            
                            <button onclick="eliminarDatos('<?php echo e($modulo->id); ?>')">
                                <i class="fas fa-trash"></i> 
                            </button>

                            
                            <button class="btneditar" onclick="modificarDatos('<?php echo e($modulo->id); ?>')">
                                <span class="fa fa-edit"></span>
                            </button>
                            
                        </div>
                    </div>
                </a>
                <?php else: ?>
                <a href="#">
                    
                    <div class="target" >
                    <img src="<?php echo e(asset('img/modulos/'. $modulo->icono)); ?>" alt="Imagen Perfil">
                    <p><?php echo e($modulo->nombre); ?></p>
                        
                        <div class="botones">
                            
                            <button onclick="eliminarDatos('<?php echo e($modulo->id); ?>')">
                                <i class="fas fa-trash"></i> 
                            </button>

                            
                            <button class="btneditar" onclick="modificarDatos('<?php echo e($modulo->id); ?>')">
                                <span class="fa fa-edit"></span>
                            </button>
                            
                        </div>
                    </div>
                </a>
  
                <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           
        </div>
     
    </section>
    
    <?php echo $__env->make('reikosoft.modulos.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php $__env->stopSection(); ?>
   
<?php echo $__env->make('reikosoft.contenedor.contenedor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/reikosoft/modulos/index.blade.php ENDPATH**/ ?>