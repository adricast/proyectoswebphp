

<?php $__env->startSection('titulo', 'Nosotros'); ?>
<?php $__env->startSection('nosotros-active', 'active'); ?>

<?php $__env->startSection('contenido'); ?>
    <?php echo $__env->make('contenidos.introempresa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('contenidos.informaciondeempresa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('contenidos.pie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('estructura.cabecera', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/paginas/nosotros.blade.php ENDPATH**/ ?>