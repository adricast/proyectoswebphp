

<?php $__env->startSection('titulo', 'ReikoSoft'); ?>
<?php $__env->startSection('reikosoft-active', 'active'); ?>

<?php $__env->startSection('contenidoreiko'); ?>

    <script src="<?php echo e(route('recursos.show', ['js/reiko', 'perfilesreiko.js'])); ?>"></script>
  
    <section class="containerreiko">
       
       <div class="contenedorformulario">
            <form action="<?php echo e(route('perfiles.update')); ?>" id="miFormulario" method="post" enctype="multipart/form-data" novalidate>
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <?php if($user->foto): ?>
                            <img src="<?php echo e(route('recursos.show', ['img/perfiles', $user->foto])); ?>"  alt="" id="imagen-preview" height="150px" width="150px">
                <?php else: ?>
                            <img src="<?php echo e(route('recursos.show', ['img', 'logotype.png'])); ?>" alt="" id="imagen-preview" height="150px" width="150px">
                <?php endif; ?>
                <input type="file" name="imagenmodulo" id="file-input" onchange="cargarImagen()">
                <button class="btn" type="button" id="quitarImagen" style="display: none;" onclick="quitarImg()">Quitar Imagen</button>
                
                <?php if(isset($user)): ?>
                    <p><?php echo e($user->nombres . " " . $user->apellidos); ?> </p>
                    <?php if(isset($user->typeUser)): ?>
                        <p><?php echo e($user->username . " - " . $user->typeUser->descripcion); ?></p>
                    <?php endif; ?>
                <?php endif; ?>
                <input type="text" name="email" id="email" value="<?php echo e($user->email); ?> " placeholder="ingresa su email">
                <input type="text" name="telefono" id="telefono" value="<?php echo e($user->telefono); ?> " placeholder="ingresa su telefono">
                <input type="text" name="direccion" id="direccion" value="<?php echo e($user->direccion); ?> " placeholder="ingresa su direccion">
                <p>Opcional si deseas cambiar contraseña </p>
                <input type="password" name="nuevacontraseña" id="nuevacontraseña"  placeholder="escribir nueva contraseña">
                <p>Confirma con tu contraseña para modificar tus datos</p>
                <input type="password" name="contraseña" id="contraseña"  placeholder="escribir nueva contraseña">
                <button type="submit" id="modificarbtn" onclick="event.preventDefault(); actualizarDatos();">Modificar</button>
              
            
            </form>
       </div>
           
        
    
    </section>
 

<?php $__env->stopSection(); ?>
   
<?php echo $__env->make('reikosoft.contenedor.contenedor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/reikosoft/perfiles/index.blade.php ENDPATH**/ ?>