<div class="reikomodal" id="editmodal">
    <div class="contenidomodal">
        <div class="bannertitulo">
            Productos
        </div>
        <div class="closemodal">
           <button onclick="cerrarModal()">
                <span class="fa fa-times"></span>
           </button>
        </div>
        <div class="cuerpomodal">
            <form action="<?php echo e(route('productos.update', '__ID__')); ?>" id="miFormulario" method="post" enctype="multipart/form-data" novalidate>
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <img src="" alt="" id="imagen-preview" style="max-width: 100%; display: none;">

                <input type="file" name="imagenmodulo" id="file-input" onchange="cargarImagen()">
                <button class="btn" type="button" id="quitarImagen" style="display: none;" onclick="quitarImg()">Quitar Imagen</button>
                <select name="tipo_producto_id" id="id_tipo_producto">
                    <?php $__currentLoopData = $tipoProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoproducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tipoproducto->id); ?>" selected><?php echo e($tipoproducto->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <select name="categoria_id" id="id_categoria">
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                            <option value="<?php echo e($categoria->id); ?>" selected><?php echo e($categoria->nombre); ?></option>
                
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="text" placeholder="Ingrese Nombre"  name="nombre" id="nombre" value="" required>
                <input type="text" placeholder="Ingrese Descripcion"  name="descripcion" id="descripcion" value="" required>
                <input type="number" placeholder="Ingrese Precio"  name="precio" id="precio" value="" required>
                <div style="display: flex; height:30px; width:auto;">
                    <label for="en_stock" style="width: 90%;">Stock </label>
                    
                    <input type="checkbox" style="height: 30px;" name="en_stock" id="en_stock" value="1">

                </div>
                <input type="text" placeholder="Ingrese Stock"  name="stock" id="stock" value="" required>
                <input type="text" placeholder="Ingrese Codigo"  name="codigo" id="codigo" value="" required>
                <select name="marca_id" id="id_marca">
                    <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                            <option value="<?php echo e($marca->id); ?>" selected><?php echo e($marca->nombre); ?></option>
                
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div style="display: flex; height:30px; width:auto;">
                    <label for="en_oferta" style="width: 90%;">Oferta </label>
                    
                    <input type="checkbox" style="height: 30px;" name="en_oferta" id="en_oferta" value="1">

                </div>  
                <input type="number" placeholder="Ingrese Precio"  name="precio_oferta" id="precio_oferta" value="" required>
                <div style="display: flex; height:30px; width:auto;">
                    <label for="publicar_web" style="width: 90%;">Publicar </label>
                    
                    <input type="checkbox" style="height: 30px;" name="publicar_web" id="publicar_web" value="1">

                </div>
                <input type="text" placeholder="Ingrese Link de Compra"  name="linkcompra" id="linkcompra" value="" required>
  
               <button type="submit" id="modificarbtn" onclick="event.preventDefault(); actualizarDatos();">Modificar</button>
              
            </form>
        </div>

    </div>
</div><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/reikosoft/productos/edit.blade.php ENDPATH**/ ?>