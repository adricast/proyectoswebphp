@extends('estructura.cabecera')

@section('titulo', 'Noticias')
@section('noticias-active', 'active')

@section('contenido')
   
    @include('contenidos.pie')
@endsection
