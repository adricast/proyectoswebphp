

<?php $__env->startSection('titulo', 'Inicio'); ?>
<?php $__env->startSection('inicio-active', 'active'); ?>

<?php $__env->startSection('contenido'); ?>
   
    <?php echo $__env->make('contenidos.introservicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('contenidos.solucionestecnologicas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('contenidos.pie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('estructura.cabecera', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/paginas/inicio.blade.php ENDPATH**/ ?>