<main class="main">
        <div class="slider-container">
            <img class="slider-image active" src="<?php echo e(route('recursos.show', ['img', 'portadaweb2.gif'])); ?>" alt="Imagen 1">
            <img class="slider-image" src="<?php echo e(route('recursos.show', ['img', 'portadaweb3.gif'])); ?>" alt="Imagen 2">
            <img class="slider-image" src="<?php echo e(route('recursos.show', ['img', 'portadaweb4.gif'])); ?>" alt="Imagen 3">
            <img class="slider-image" src="<?php echo e(route('recursos.show', ['img', 'portadaweb5.gif'])); ?>" alt="Imagen 4">
            <img class="slider-image" src="<?php echo e(route('recursos.show', ['img', 'portadaweb.gif'])); ?>" alt="Imagen 4">
            <div class="slider-overlay"></div>
        </div>
   
        <div class="contenido">
            <div class="imagen">
                <img src="<?php echo e(route('recursos.show', ['img', 'logotype.png'])); ?>" alt="">
            </div>
            <div class="titulo">
                <h1>Ingreso al Sistema</h1>
            </div>
            <div class="seccion">
                
                <h2><i class="fa fa-key" aria-hidden="true"></i></h2>
                <form action="<?php echo e(route('enviarFormulario')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="usuario">Usuario:</label>
                    <input type="user" id="usuario" name="usuario" value="" required>


                    <label for="password">Email:</label>
                    <input type="password" id="password" name="password" value="" required>


                    <input type="submit" value="Ingresar">
                </form>
           
            </div>
        </div>

        <script> 
           
           var slideIndex = 0;
          
           funcionslider();
         
       </script>
</main><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/reikosoft/ingreso/ingreso.blade.php ENDPATH**/ ?>