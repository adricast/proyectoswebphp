<main class="main">


        <script src="<?php echo e(route('recursos.show', ['js/reiko', 'contactanos.js'])); ?>"></script>
        <script>
        var StoreUrl = "<?php echo e(route('contactanos.store')); ?>";   
        </script>
        <div class="contenido">
            <div class="imagen">
                <img src="<?php echo e(route('recursos.show', ['img', 'mail.png'])); ?>" alt="">
            </div>
            <div class="titulo">
                <h1>Contactanos</h1>
            </div>
            <div class="seccion">
                
                <h2><i class="fa fa-envelope" aria-hidden="true"></i></h2>
                <form action="<?php echo e(route('contactanos.store')); ?>" id="miFormulario" method="post" enctype="multipart/form-data" novalidate>
            
                    <?php echo csrf_field(); ?>

                    <input type="text" id="nombre" name="nombre" placeholder="Ingrese su nombre" value="<?php echo e(isset($datos['nombre']) ? $datos['nombre'] : ''); ?>" required>
                    
               
                    <input type="phone" id="telefono" name="telefono" placeholder="Ingrese su numero de telefono" value="<?php echo e(isset($datos['nombre']) ? $datos['nombre'] : ''); ?>" required>
                  
                 
                    <input type="text" id="asunto" name="asunto" placeholder="Ingrese asunto del tema a tratar" value="<?php echo e(isset($datos['nombre']) ? $datos['nombre'] : ''); ?>" required>

                
                    <input type="email" id="correo" name="correo" placeholder="Ingrese su correo electronico" value="<?php echo e(isset($datos['correo']) ? $datos['correo'] : ''); ?>" required>


                    <textarea id="mensaje" placeholder="Ingrese su mensaje" name="mensaje" rows="4" required><?php echo e(isset($datos['mensaje']) ? $datos['mensaje'] : ''); ?></textarea>
                    <button style="margin-right: 10px; background-color:blue; color:white; padding:5px; border:2px solid white;" type="submit" onclick="event.preventDefault(); guardarDatos();">Enviar</button>
            
                </form>
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                
            </div>
        </div>

      
</main><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/contenidos/contacto.blade.php ENDPATH**/ ?>