


<?php $__env->startSection('titulo', 'registrousuario'); ?>
<?php $__env->startSection('registeruser-active', 'active'); ?>

<?php $__env->startSection('contenido'); ?>
<main class="main">
 
        <div class="contenido">
         
            <div class="titulo">
                <h1>Ingreso al Sistema</h1>
            </div>
            <div class="seccion">
                
               
                <h2><img src="<?php echo e(route('recursos.show', ['img', 'logotype.png'])); ?>" alt="" width="40px" height="40px" >
           </h2>
                <form action="<?php echo e(route('login')); ?>" method="post" novalidate>
                <?php echo csrf_field(); ?>
              

                    <input type="user" placeholder="Ingresa el usuario" id="usuario" name="name" class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="" required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <input type="password" placeholder="Ingresa contraseña" id="password" name="password" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="elementoformbtn" style="display:flex;" >
                        <label for="remembercheck" style="margin-right:10px;">Recordar</label>
                        <input type="checkbox" name="remember" id="remembercheck">
                        
                    </div>
                 
                  
                    <?php if(session('mensaje')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('mensaje')); ?>

                    </div>
                    
                    <?php endif; ?>
                    <input type="submit" value="Ingresar">
                </form>
              
                <a href="<?php echo e(route('register')); ?>"> Crear usuario </a>

            </div>
        </div>

     
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('estructura.cabecera', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/reikosoft/auth/login.blade.php ENDPATH**/ ?>