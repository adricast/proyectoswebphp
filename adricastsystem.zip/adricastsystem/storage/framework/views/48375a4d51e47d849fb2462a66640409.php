

<?php $__env->startSection('titulo', 'ReikoSoft'); ?>
<?php $__env->startSection('reikosoft-active', 'active'); ?>

<?php $__env->startSection('contenidoreiko'); ?>
    <script src="<?php echo e(route('recursos.show', ['js/reiko', 'modulosreiko.js'])); ?>"></script>
    <script>
        var StoreUrl = "<?php echo e(route('cmodulos.store')); ?>";   
    </script>
    <section class="containerreiko">
        
        <div class="contenedorformularios">
            <form action="<?php echo e(route('cmodulos.store')); ?>" id="miFormulario" method="post" enctype="multipart/form-data" novalidate>
                <?php echo csrf_field(); ?>
                <img src="" alt="" id="imagen-preview" style="max-width: 100%; display: none;">
                <input type="file" name="imagenmodulo" id="file-input" onchange="cargarImagen()">
                <button class="btn" type="button" id="quitarImagen" style="display: none;" onclick="quitarImg()">Quitar Imagen</button>
  
                <input type="text" name="nombre" id="nombre" placeholder="Nombre del Modulo">
                <input type="text" name="descripcion" id="descripcion" placeholder="Descripcion del Modulo">
                <input type="text" name="ruta" id="ruta" placeholder="Ruta del Modulo">
                <div style="display:flex;">
                <button style="margin-right: 10px;" type="submit" onclick="event.preventDefault(); guardarDatos();">Guardar</button>
                <button style="margin-right: 10px;" onclick="event.preventDefault(); principal();">Cancelar</button>
                </div>
            </form>
      
         
        </div>
    
    </section>
<?php $__env->stopSection(); ?>
   
<?php echo $__env->make('reikosoft.contenedor.contenedor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/reikosoft/modulos/create.blade.php ENDPATH**/ ?>