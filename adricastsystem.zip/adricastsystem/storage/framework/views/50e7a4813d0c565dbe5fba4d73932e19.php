

<?php $__env->startSection('titulo', 'ReikoSoft'); ?>
<?php $__env->startSection('reikosoft-active', 'active'); ?>

<?php $__env->startSection('contenidoreiko'); ?>

    <script src="<?php echo e(route('recursos.show', ['js/reiko', 'contactoreiko.js'])); ?>"></script>

    Busqueda
    <input type="text" name="busqueda" id="busqueda" placeholder="Busqueda de Datos" onkeyup="consultaDatos()" style="width: 200px;">
    <select name="select" id="select" style="width: 150px; padding:5px; border-radius:5px; height:40px;" onchange="consultaDatos()">
        <option value="leido">Leido</option>
        <option value="no_leido">No Leido</option>
        <option value="todos">Todos</option>
    </select>
    <section class="containerreiko2">
    
      

       <div class="contenedormensajeria">
            <div class="contenidomensajeria" id="contenidomensajeria">
            <?php $__currentLoopData = $mensajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($mensaje->status =='leido'): ?>
                    <p style="color: green;">Mensaje Leido</p>
                    <div class="mensaje" style="border: 1px solid green;">
                    
                <?php elseif($mensaje->status =='no_leido'): ?>
                    <p style="color: blue;">Mensaje no Leido</p>
                    <div class="mensaje" style="border: 1px solid blue;">
                <?php endif; ?>
                    <div class="elemento">
                        <span class="etiqueta">Nombre:</span>
                        <span class="dato"><?php echo e($mensaje->nombre); ?></span>
                    </div>
                    <div class="elemento">
                        <span class="etiqueta">Correo:</span>
                        <span class="dato"><?php echo e($mensaje->correo); ?></span>
                    </div>
                    <div class="elemento">
                        <span class="etiqueta">Asunto:</span>
                        <span class="dato"><?php echo e($mensaje->asunto); ?></span>
                    </div>
                    <div class="elemento" style="display: flex;">
                        <button type="submit" onclick="obtenerDatos('<?php echo e($mensaje->id); ?>')" class="btnver">Ver</button>
                        <button type="submit" onclick="eliminarDatos('<?php echo e($mensaje->id); ?>')" class="btneliminar">Eliminar</button>
                    </div>
                </div>
              
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               

            </div>
       
       </div>
        
       
    </section>
    
   
    <?php echo $__env->make('reikosoft.contacto.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('reikosoft.contenedor.contenedor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/reikosoft/contacto/index.blade.php ENDPATH**/ ?>