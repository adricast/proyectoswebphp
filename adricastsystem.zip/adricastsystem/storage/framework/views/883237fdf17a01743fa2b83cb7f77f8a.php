
    <?php if(auth()->guard()->check()): ?>
        
        <?php echo $__env->make('reikosoft.presentacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
        
        <?php echo $__env->make('reikosoft.auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php echo $__env->make('contenidos.pie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/paginas/reikosoft.blade.php ENDPATH**/ ?>