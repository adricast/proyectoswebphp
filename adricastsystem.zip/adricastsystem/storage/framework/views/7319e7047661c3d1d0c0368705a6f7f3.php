

<?php $__env->startSection('titulo', 'ReikoSoft'); ?>
<?php $__env->startSection('reikosoft-active', 'active'); ?>

<?php $__env->startSection('contenidoreiko'); ?>
    <script src="<?php echo e(route('recursos.show', ['js/reiko', 'productosReiko.js'])); ?>"></script>
    <script>
        var StoreUrl = "<?php echo e(route('productos.store')); ?>";   
    </script>
    <section class="containerreiko">
        
        <div class="contenedorformularios">
            <form action="<?php echo e(route('productos.store')); ?>" id="miFormulario" method="post" enctype="multipart/form-data" novalidate>
                <?php echo csrf_field(); ?>
                    <img src="<?php echo e(route('recursos.show', ['img', 'logotype.png'])); ?>" alt="" id="imagen-preview" height="150px" width="150px">
        
                    <input type="file" placeholder="Ingrese Foto"  name="imagenproducto" id="file-input" onchange="cargarImagen()" value="" required>
                    <button class="btn" type="button" id="quitarImagen" style="display: none;" onclick="quitarImg()">Quitar Imagen</button>
                    <select name="tipo_producto_id" id="id_tipo_producto">
                        <?php $__currentLoopData = $tipoProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoproducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tipoproducto->id); ?>" selected><?php echo e($tipoproducto->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <select name="categoria_id" id="id_categoria">
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                                <option value="<?php echo e($categoria->id); ?>" selected><?php echo e($categoria->nombre); ?></option>
                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="text" placeholder="Ingrese Nombre"  name="nombre" id="nombre" value="" required>
                    <input type="text" placeholder="Ingrese Descripcion"  name="descripcion" id="descripcion" value="" required>
                    <input type="number" placeholder="Ingrese Precio"  name="precio" id="precio" value="" required>
                    <div style="display: flex; height:30px; width:auto;">
                        <label for="en_stock" style="width: 90%;">Stock </label>
                        
                        <input type="checkbox" style="height: 30px;" name="en_stock" id="en_stock" value="1">
                        
                    </div>
                    <input type="text" placeholder="Ingrese Stock"  name="stock" id="stock" value="" required>
                    <input type="text" placeholder="Ingrese Codigo"  name="codigo" id="codigo" value="" required>
                    <select name="marca_id" id="id_marca">
                        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                                <option value="<?php echo e($marca->id); ?>" selected><?php echo e($marca->nombre); ?></option>
                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div style="display: flex; height:30px; width:auto;">
                        <label for="en_oferta" style="width: 90%;">Oferta </label>
                        
                        <input type="checkbox" style="height: 30px;" name="en_oferta" id="en_oferta" value="1">
                        
                    </div>

                   <input type="number" placeholder="Ingrese Precio"  name="precio_oferta" id="precio_oferta" value="" required>
                  
                   <div style="display: flex; height:30px; width:auto;">
                        <label for="publicar_web" style="width: 90%;">Publicar </label>
                        <input type="checkbox" style="height: 30px;" name="publicar_web" id="publicar_web" value="1">
                        
                    </div>
                    <input type="text" name="linkcompra" id="linkcompra" placeholder="link compra individual">
                <div style="display:flex;">
                <button style="margin-right: 10px;" type="submit" onclick="event.preventDefault(); guardarDatos();">Guardar</button>
                <button style="margin-right: 10px;" onclick="event.preventDefault(); principal();">Cancelar</button>
                </div>
                
            </form>
      
            <script>
                
            </script>
   
        </div>
    
    </section>

<?php $__env->stopSection(); ?>
   
<?php echo $__env->make('reikosoft.contenedor.contenedor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/reikosoft/productos/create.blade.php ENDPATH**/ ?>