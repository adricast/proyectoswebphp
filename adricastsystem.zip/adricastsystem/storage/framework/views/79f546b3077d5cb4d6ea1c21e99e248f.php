

<?php $__env->startSection('titulo', 'reikosoft'); ?>
<?php $__env->startSection('reiko-active', 'active'); ?>

<?php $__env->startSection('contenido'); ?>
  
<section id="reikocontenedor">
    
    <div id="infosystem">
        <?php if(isset($user)): ?>
            <?php if(isset($user->foto)): ?>
                <img src="<?php echo e(route('recursos.show', ['img/perfiles', $user->foto])); ?>" alt="" width="40px" height="40px" >
            <?php else: ?>
                <img src="<?php echo e(route('recursos.show', ['img', 'logotype.png'])); ?>" alt="" width="40px" height="40px" >
            <?php endif; ?>
            <?php if(isset($user->typeUser->descripcion)): ?>
                <p>Perfil: <?php echo e($user->typeUser->descripcion); ?> -</p>
                
            <?php endif; ?>

            <p><?php echo e($user->name); ?></p>
            <!-- Puedes mostrar otros atributos del usuario aquí -->
        <?php else: ?>
            <p>No hay información de usuario disponible.</p>
        <?php endif; ?>
         <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Salir</a>
                
    </div>
    <div id="contenedormodulos">
        <button class="prevbuttonmenu" id="prevButton">&#8249;</button>
        <div id="modulos">
            
            <a href="<?php echo e(route('posts.index')); ?>">
                <img src="<?php echo e(route('recursos.show', ['img/modulos', 'home.png'])); ?>"  alt="" width="40px" height="40px" title="Home">
            </a>
            <a href="<?php echo e(route('cmodulos.index')); ?>">
                <img src="<?php echo e(route('recursos.show',['img/modulos', 'modulos.png'])); ?>" alt="" width="40px" height="40px" title="Modulos">
            </a>
            <?php $__currentLoopData = $modulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Route::has($modulo->ruta.'.index')): ?>
                <a href="<?php echo e(route($modulo->ruta.'.index')); ?>">
                    <img src="<?php echo e(asset('img/modulos/' . $modulo->icono)); ?>" alt="<?php echo e($modulo->nombre); ?>" width="40px" height="40px" title="<?php echo e($modulo->nombre); ?>">
                </a>
                <?php else: ?>
                <a href="#">
                    <img src="<?php echo e(asset('img/modulos/'. $modulo->icono)); ?>" alt="Imagen Perfil" width="40px" height="40px" title="<?php echo e($modulo->nombre); ?>">
                </a>
                <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
        </div>
        <button class="nextbuttonmenu" id="nextButton">&#8250;</button>
        <script> funciontarjeta2();</script>
       
    </div>
    <div id="contenedorprincipal">
            <?php echo $__env->yieldContent('contenidoreiko'); ?>
            <!-- Scripts -->
            <?php echo $__env->yieldPushContent('scripts'); ?>
    </div>

    <div id="piepagina">
         REIKO TECNOLOGY 2023
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('estructura.cabecera', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adria\OneDrive\Escritorio\adricast\adricastsystem\resources\views/reikosoft/contenedor/contenedor.blade.php ENDPATH**/ ?>