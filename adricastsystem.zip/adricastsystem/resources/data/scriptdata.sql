create database reiko;
use reiko;
create 