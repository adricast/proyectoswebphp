<footer class="piepagina">
  <div class="seccionespie">
      <div class="seccion1">
        <ul class="social-media-icons">
              <li><a href="#"><i class="fab fa-facebook"></i></a></li>
              <li><a href="#"><i class="fab fa-twitter"></i></a></li>
              <li><a href="#"><i class="fab fa-instagram"></i></a></li>
              <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
        </ul>
         
      </div>
      <div class="seccion2">  
          <a href="{{route('paginas.empleo')}}">Trabaja con nosotros </a>
      </div>
      <div class="seccion3">  
          <a href="">Servicios</a>
      </div>
      <div class="seccion4">  
          <a href="{{route('paginas.contactanos')}}">Contactanos</a>
      </div>
      <div class="seccion5">
          <a href="{{route('paginas.noticias')}}">Noticias</a>
      </div>
      <div class="seccion6">  
          <a href="{{route('paginas.nosotros')}}">Acerca de nosotros </a>
      </div>
      <div class="seccion7">  
          <a href="">Cursos</a>
      </div>
      <div class="seccion8">  
          <a href="{{route('paginas.tecnologias')}}">Tecnologías</a>
      </div>
      <div class="seccion9">
          <a href="">Comunidades</a>
      </div>
      <div class="seccion10">
         Derechos reservados 2023 © ADRICAST SYSTEM
      </div>
  </div>
</footer>