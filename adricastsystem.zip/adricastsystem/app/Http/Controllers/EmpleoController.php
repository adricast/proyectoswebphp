<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EmpleoController extends Controller
{
    //
    public function empleo()
    {
        return view('paginas.empleo');
    }
}
