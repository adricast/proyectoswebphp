<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ReikosoftController extends Controller
{
    //
    public function reikosoft()
    {
        return view('paginas.reikosoft');
    }
}
