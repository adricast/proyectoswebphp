document.addEventListener("scroll", manejarScroll);
